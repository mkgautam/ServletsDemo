import React from 'react';
import App from '../App';
import renderer from 'react-test-renderer';

describe('components testing', () => {
    describe('App testing', () => {

        it('renders correctly', () => {
            var domtree = renderer.create(<App/>).toJSON();
            expect(domtree).toMatchSnapshot();
        });
    });
});