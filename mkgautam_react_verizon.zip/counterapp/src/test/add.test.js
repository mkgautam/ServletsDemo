import { add } from '../add.js';

describe('add()', function() {

    it('add two numbers', function(){
        expect(add(2,3)).toEqual(5);
    });

    it('does not add the third numbers', function(){
        expect(add(2,3,5)).toEqual(add(2,3));
    });

});