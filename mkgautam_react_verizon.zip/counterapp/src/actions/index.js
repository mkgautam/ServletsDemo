import * as actionType from './ActionType';
import { SAVE_COMMENT } from './types';

export const addCounter = (newValue) => ({
    type: actionType.ADD_COUNTER,
    payload: newValue
});

export const removeCounter = (newValue) => ({
    type: actionType.REMOVE_COUNTER,
    payload: newValue
});

export function saveComment(comment) {
    return {
        type: SAVE_COMMENT,
        payload: comment
    }
};