import React, { Component } from 'react';
export  default class Footer extends Component {
  render() {
    return (
      <div>
       <h3 className="footer">Copyright Reserved to Mritunjay Gautam</h3>
      </div>
    );
  }
}


