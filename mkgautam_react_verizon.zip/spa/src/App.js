import React from 'react';
import './App.css';
import { Heading } from './Components/Heading';
import { Layout } from './Components/Layout';
import Footer from './Components/Footer';

function App() {
  return (
    <div>
      <Heading></Heading>
      <div>
        <Layout></Layout>
      </div>
      <Footer></Footer>
    </div>
  );
}

export default App;
