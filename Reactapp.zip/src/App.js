import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Header} from './components/Header';
import {Footer} from './components/Footer';
import {Login} from './components/Login';
import Dashboard from './components/Dashboard';


function App() {
  return (
    <div className="App">
      <header >
        <img src={logo} width="80" height="80" className="App-logo" alt="logo"/>
        <h1 className="App-title">React and Redux</h1>
        <Header title="React SPA Project"/>
        <Login portal="Google"/>
        <Dashboard/>
        <Footer/>
      </header>
    </div>
  );
}

export default App;
