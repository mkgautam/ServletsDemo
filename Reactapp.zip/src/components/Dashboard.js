import React, {Component} from 'react';
import StatefulApp from './PropsStates/StatefulApp';
import Grid from './PropsStates/Grid';
import TextInput from './PropsStates/TextInput';
import ChildParentInvoke from './ParentChild/ChildParentInvoke';
import RefsDemo from './ParentChild/refsDemo';

//Stateful Container Component
export default class Dashboard extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div>
                <StatefulApp></StatefulApp>
                <Grid></Grid>
                <TextInput></TextInput>
                <ChildParentInvoke></ChildParentInvoke>
                <RefsDemo></RefsDemo>
            </div>
        )
    }
}