/* 
// npm install redux --save
import { createStore, applyMiddleware } from 'redux';
//npm install redux-logger --save-dev
import logger from 'redux-logger';

//create reducers to update store
const reducer = function(state, action) {
    if (action.type === 'INC') {
        return state + action.payload;
    } else if (action.type === 'DEC') {
        return state - action.payload;
    } else {
        return state;
    }
}

const middleware = applyMiddleware(logger); // applyMiddleware(logger <comma separated other middlewares>); 
//creating store and attaching to reducer with initial state
//const store = createStore(reducer, 1);
const store = createStore(reducer, 1, middleware);

//subscribe to store to get new state
store.subscribe( () => {
    console.log('Store changed: ' + store.getState())
});

//Dispatch action to  invoke reducer
store.dispatch({type: 'INC', payload: 1});
store.dispatch({type: 'INC', payload: 3});
store.dispatch({type: 'DEC', payload: 20});
 */

//**************************************************************************************** */

//combined example with redux and redux extension tool

 /* import {combineReducers, applyMiddleware, createStore} from 'redux';
 import logger from 'redux-logger';

 //npm install redux-devtools-extension --save-dev
 import { composeWithDevTools } from 'redux-devtools-extension';

 const userReducer = ( state = {}, action ) => {
     switch ( action.type ) {
         case 'CHANGE_NAME': {
             return state = {...state, name: action.payload}
         }
         case 'CHANGE_AGE': {
            return state = {...state, name: action.payload}
         }
         default: {
            
         }
     }
     return state;
 }

 const tweetReducer = ( state = {}, action ) => {
     return state;
 }

 const reducers = combineReducers({
     user: userReducer,
     tweets: tweetReducer
 })

 const store = createStore ( reducers, composeWithDevTools(applyMiddleware(logger)));

 //subscribe to store to get new state
store.subscribe( () => {
    console.log('Store changed: ' + store.getState())
});

//Dispatch action to  invoke reducer
store.dispatch({type: 'CHANGE_NAME', payload: 'Gautam'});
store.dispatch({type: 'CHANGE_AGE', payload: 25});
store.dispatch({type: 'CHANGE_NAME', payload: 'Mritunjay'}); */

//**************************************************************************************** */

//npm install redux-thunk --save
//npm install axios --save

/* import {applyMiddleware, createStore} from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';
import axios from 'axios';
import { composeWithDevTools } from 'redux-devtools-extension';

//state tree
const initialState = {
    fetching: false,
    fetched: false,
    user: [],
    error: null
}

const reducer = ( state= initialState, action) => {
    switch ( action.type ) {
        case 'FETCH_USERS_START': {
            return {...state, fetching: true};
        }
        case 'FETCH_USERS_ERROR': {
           return {...state, fetching: false, error: action.payload};
        }
        case 'RECIEVE_USERS': {
            return {...state, fetching: false, fetched: true, users: action.payload};
        }
        default: {
           return state;
        }
    }
}

const middleware  = applyMiddleware(thunk, logger);
const store = createStore ( reducer, composeWithDevTools(middleware));

//thunk middleware  expects only one dispatch
store.dispatch((dispatch) => {
    //multiple action soccur with single action
    dispatch({type: 'FETCH_USERS_START'})

    axios.get('https://jsonplaceholder.typicode.com/users')
    .then ( (response) => {
        dispatch({type:'RECIEVE_USERS', payload: response.data})
    })
    .catch((error) => {
        dispatch({type:'FETCH_USERS_ERROR', payload: error})
    })
}) */

//**************************************************************************************** */



import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import './index.css';

import allReducers from './reducers';
import App from './components/App';

import logger from 'redux-logger';
import { composeWithDevTools } from 'redux-devtools-extension';

const store = createStore( allReducers, composeWithDevTools(applyMiddleware(logger)));

//connect store with provider with app
ReactDOM.render(
    <Provider store={store}>
        <App/>
    </Provider>,
    document.getElementById('root')
)