import data from '../store/Store';

export default (state = null, action) => {
    // returing initial state of trainer list
    return state = data; //Mocked Data
}