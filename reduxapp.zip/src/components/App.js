import React from 'react';
import TrainerList from '../containers/trainer-list';
import TrainerDetails from '../containers/trainer-details';


const App = () => (
    <div>
        <h2>Trainer List - Verizon Communications</h2>
        <TrainerList/>
        <br/>
        <h2>Trainer Details</h2>
        <TrainerDetails></TrainerDetails>
    </div>
)

export default App;