import React from 'react';

export default class CompLifeCycle extends React.Component {

    constructor (props) {
        //1. Initialization Phase
        super(props);
        this.state = {
            data: 0,
            msg: 'Inital data...'
        }
        //this.setNewNumber = this.setNewNumber.bind(this);
        //this.updateState = this.updateState.bind(this);
    }

    setNewNumber (e) {
        this.setState(
            {
                data: this.state.data + 1
            }
        )
    }

    updateState (e) {
        this.setState(
            {
                msg: e.target.value
            }
        )
    }

    //2. Initial Render
    render () {
        return(
            <div>
                <button onClick={ (event) => {this.setNewNumber(event)} }>INCREMENT</button>
                <Content myNumber = {this.state.data} ></Content>
                <br/>
                <input type="text" value={this.state.msg} onChange= { (e) => {this.updateState(e)} } />
                <h3>{this.state.msg}</h3>
            </div>
        )
    }
}//parent component is completed

//child component
class Content extends React.Component {
    constructor (props) {
        super(props);
        this.state = {
            name: 'Gautam'
        }
        console.log('In COnstructor'+props.myNumber);
        console.log('1. Content constructor fired - Initializatuion phase');
        this.handleScroll = this.handleScroll.bind(this);
    }

    //register the handler
    handleScroll(e) {
        console.log('Handle scroll is executed');
    }

    componentWillMount() {
        console.log('1. componentWillMount =>' + this.props.myNumber);
    }

    componentDidMount() {
        console.log('2. componentDidMount - reset data or reinitialized data');
        console.log('componentDidMount => '+ this.props.myNumber);
    }

    componentWillReceiveProps(nextProps) {
        console.log('3. set default props here and valiadte props here');
        console.log('props in component will recieve:'+nextProps.myNumber);
        //the old props can be accessed via 'this.props' insdide this
        this.setState ({
            isPassed: nextProps.myNumber >= 0
        });
    }

    //in future versions, above method componentWillReceiveProps replaced with below method
    static getDerivedStateFromProps(props, state) {
        console.log('getDerivedStateFromProps');
        console.log(state.name);
        return {};
    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log('Decide whether to re-render or not');
        console.log(nextState);
        console.log('4. component is rendered');
        if (nextProps.myNumber > 3) {
            return true;
        } else {
            return false; //changed to false to stop rendering
        }
    }

    componentWillUpdate(nextProps, nextState) {
        console.log('5. componentWillUpdate' + nextProps.myNumber);
    }

    componentDidUpdate(prevProps, prevState) {
        console.log('7. componentDidUpdate - you can rollback state here to previos state');
    }

    componentDidCatch(err) {
        console.log('some error occured... log it to server in DB');
    }

    componentWillUnmount() {
        console.log('8. componentWillUnmount - release the resources here or cache data ');
        window.removeEventListener('scroll', this.handleScroll);
    }

    render() {
        return(
            <div>
                <h3>{this.props.myNumber}</h3>
            </div>
        )
    }

}