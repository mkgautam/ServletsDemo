import React from 'react';

//SFC
export function Login(props) {
    return (
        <h3><a href="https://www.google.com">Login To {props.portal}</a></h3>
    );
}