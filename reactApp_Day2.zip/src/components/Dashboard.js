import React, {Component} from 'react';
import StatefulApp from './PropsStates/StatefulApp';
import Grid from './PropsStates/Grid';
import TextInput from './PropsStates/TextInput';
import ChildParentInvoke from './ParentChild/ChildParentInvoke';
import RefsDemo from './ParentChild/refsDemo';
import Context from './ContextAPI/Context';
import CompLifeCycle from './LifeCycle/CompLifeCycle';
import WeatherComponent from './LifeCycle/WeatherCmponent';
import FormApp from './FormsValidation/FormApp';
import MyHoc from './Hoc/Hoc'

//Stateful Container Component
export default class Dashboard extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div>
                <FormApp></FormApp>
                <WeatherComponent></WeatherComponent>
                <StatefulApp></StatefulApp>
                <Grid></Grid>
                <TextInput></TextInput>
                <ChildParentInvoke></ChildParentInvoke>
                <RefsDemo></RefsDemo>
                <Context></Context>
                <CompLifeCycle></CompLifeCycle>
                <MyHoc></MyHoc>
            </div>
        )
    }
}