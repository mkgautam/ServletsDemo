import React from 'react';

//1. Create the Context
const MyContext = React.createContext(); 

//2. Create Provider Componenet
class MyProvider extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            name: 'Gautam',
            salary: 5000,
            job: 'Engineer'
        }
    }

    render() {
        return (
            <MyContext.Provider value={
                {
                    //data
                    state: this.state,
                    //function
                    incrementSalary: () => this.setState ({
                        salary: this.state.salary +1000
                    })
                }
            }>
            {
                //Making context available to children
                this.props.children
            }
            </MyContext.Provider>
        )
    }
}

//3. Wrap main app into MyProvider to access the context
export default class Context extends React.Component {
    render () {
        return (
            <MyProvider>
                <div className="bg-success">
                    <h2 className="bg-info">React Context API Demo</h2>
                    <Family/>
                </div>
            </MyProvider>
        )
    }
}


const Family = () => {
    return (
        <div>
            <Person/>
            <Employee/>
        </div>
    )
}

class Person extends React.Component {
    render () {
        return (
            <div>
                <MyContext.Consumer>
                    {
                        (Context) => (
                            //React Fragment to avoid conflict with above div as context is returning 
                            <React.Fragment>
                                <h3 className="bg-primary">Person Details</h3>
                                <p>Hi!! {Context.state.name}</p>
                                <p className="bg-danger">Salary: {Context.state.salary}</p>
                                <p>Job!! {Context.state.job}</p>
                                <button className="" onClick={Context.incrementSalary}>Increment Salary</button>
                            </React.Fragment>
                        )
                    }
                </MyContext.Consumer>
            </div>
        )
    }
}

class Employee extends React.Component {
    render () {
        return (
            <div>
                <MyContext.Consumer>
                    {
                        (context) => (
                            //React Fragment to avoid conflict with above div
                            <React.Fragment>
                                <h3>Employee Details</h3>
                                <p>Hi!! {context.state.name}</p>
                            </React.Fragment>
                        )
                    }
                </MyContext.Consumer>
            </div>
        )
    }
}