import React from 'react';

//Stateless Function Component(SFC)
export const Footer = () => {
    return (
        <div>
            <h4 className="text-center"> Copyright reserved to Gautam</h4>
        </div>
    );
}